<?php
require 'function.php';
$cari=mysqli_query($database,"select*from isi");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Aulia</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
    <div class="header">
    <div class="gambar"><img src="foto.jpg" alt="ini gambar logo">
    </div>

    <?php
foreach($cari as $cari2):
?>

    <h1><?php echo $cari2["nama"]  ?></h1>
    <h3><?php echo $cari2["hobi"]  ?></h3>
    <?php
endforeach;
?>
    </div>
    <div class="main">
<div class="left">
    <h2>Informasi Indentitas</h2>
    <p><strong>Nama</strong> <?php echo $cari2["nama"]  ?></p>
    <p><strong>Alamat</strong> <?php echo $cari2["alamat"]   ?></p>
    <p><strong>Telepon</strong> <?php echo $cari2["telepon"]   ?></p>
    <p><strong>Jenis kelamin</strong> <?php echo $cari2["jenis_kelamin"]   ?></p>
    <p><strong>Skil</strong> <?php echo $cari2["skil"]  ?></p>

    <h2>Pendidikan</h2>
    <p><strong><?php echo $cari2["pendidikan"]  ?></strong></p>
   
</div>

<div class="right">
    <h2>Pekerjaan</h2>
    <p><strong><?php echo $cari2["pekerjaan"]  ?></strong></p>
   

   <h3>Kepribadian</h3>
    <p><strong>Sifat</strong> </p>
    <li><?php echo $cari2["kepribadian"]  ?></li>
   
</div>
    </div>
    </div>
</body>
</html>