<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web data cv</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">data cv</a>
          </div>
          </div>
          <ul class="menu">
        <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="data-cv.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data Admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
         </ul>
    </div>
    <div class="konten">
            <h1>E- Perpustakaan</h1>
            <h2>Selamat datang di Halaman Perpustakaan SMKN 6 Kota JAMBI </h2>
            <p>Dengan adanya website Perpustakaan ini mempermudah dalam pencarian Buku</p>
          </div>
          <div class="fotter">
            <p>Hak Cipta 2024 © Pengembangan Perangkat Lunak dan Gim</p>
          </div>
    </body>
</html>