<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';

$hapus=$_GET["no"];
$data=mysqli_query($database,"select*from user where no=$hapus");

if(isset($_POST["tombol"])){
    
     
   

    if(editAdmin($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Diperbarui');
        document.location.href='data-admin.php';
        </script>
        ";
        }
        else{echo"Gagal";}

}

?>


<!doctype html>
<html>
<head>
<title>
Edit admin
</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">data cv</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a></li>
          <li class="menu-item"><a href="data-cv.php">Data CV</a></li>
          <li class="menu-item"><a href="data-admin.php">Data Admin</a></li>
          <li class="menu-item"><a href="keluar.php">Keluar</a></li>
         </ul>
    </div>
    <div class="konten">

<?php
while( $cari=mysqli_fetch_assoc($data)):


?>

<h1> Edit Admin </h1>
<br>
<form method="POST">
  


<ul>

<li><label> USERNAME </label></li>
<li><input type="text" name="username" value="<?php echo $cari["username"]   ?>"></li>
<li><label> PASSWORD  </label></li>
<li><input type="text" name="password" value="<?php echo $cari["password"]   ?>"></li>
<li><button type="submit" name="tombol"> Diperbarui </button> </li>
</ul>

<?php
endwhile;
?>

</form>
</div>
</body>
</html> 