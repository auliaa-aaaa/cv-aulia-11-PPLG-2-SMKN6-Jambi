<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';

$hapus=$_GET["no"];

if(hapus($hapus)>0){
    echo "
    <script>
    alert('Data Berhasil Dihapus');
    document.location.href='data-cv.php';
    </script>
    ";
    }
    else{echo"Gagal";}




?>