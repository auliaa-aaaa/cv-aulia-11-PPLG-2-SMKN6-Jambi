<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';
$cari=mysqli_query($database,"select*from isi");
if (isset($_POST["tombol"])){
    $Pencarian= $_POST["pencarian"];
   $datayangdicari= "select *from isi where
    nama like '%$Pencarian%' or
    alamat like '%$Pencarian%' or
    telepon like '%$Pencarian%' or
    jenis_kelamin like '%$Pencarian%' or
    skil like '%$Pencarian%'";
    $cari=mysqli_query($database, $datayangdicari);
} else{
    $cari=mysqli_query($database,"select*from isi");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web data cv</title>
    <link rel="stylesheet" type="text/css" href="style.css">

    </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">data cv</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a></li>
          <li class="menu-item"><a href="data-cv.php">Data CV</a></li>
        <li class="menu-item"><a href="data-admin.php">Data Admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
         </ul>
    </div>
    <div class="konten">
<h1> DATA CV </h1>
<a href="tambah.php">Tambah data</a>
<form action="" method="post">
    <input type="text"name="pencarian">
    <button type="submit" name="tombol"> Cari </button>
</form>
<div class="table">
<table border="1" cellpadding="10" cellspacing="0">

<tr class="table-header">
<th>NO</th>
<th>NAMA</th>
<th>HOBI</th>
<th>ALAMAT</th>
<th>TELEPON</th>
<th>JENIS KELAMIN</th>
<th>SKIL</th>
<th>PENDIDIKAN</th>
<th>PEKERJAAN</th>
<th>KEPRIBADIAN</th>
<th>AKSI</th>

</tr>  

<?php
$mengurutkan=1;

?>
<?php
foreach($cari as $cari2):



?>
 
 <tr><td class="table-header1"><?php echo $mengurutkan    ?></td>
<td class="table-header2"><?php echo $cari2["nama"]  ?></td>
<td class="table-header2"><?php echo $cari2["hobi"]  ?></td>
<td class="table-header3"><?php echo $cari2["alamat"]   ?></td>
<td class="table-header4"><?php echo $cari2["telepon"]   ?></td>
<td class="table-header5"><?php echo $cari2["jenis_kelamin"]   ?></td>
<td class="table-header6"><?php echo $cari2["skil"]  ?></td>
<td class="table-header8"><?php echo $cari2["pendidikan"]  ?></td>
<td class="table-header6"><?php echo $cari2["pekerjaan"]  ?></td>
<td class="table-header6"><?php echo $cari2["kepribadian"]  ?></td>
<td class="table-header7"><a href="edit.php?no=<?php echo $cari2["no"] ?>">Edit</a> |
<a href="hapus.php?no=<?php echo $cari2["no"] ?>">Hapus</a></td>
</tr>

<?php
$mengurutkan++;

?>
<?php
endforeach;
?>

</table> 
</div>
</div>
<div class="footer">
<p>
Logo SMKN 6 
</p>
</div>

</body>
</html>