<?php
$database=mysqli_connect("localhost","root","","cv_aulia");

function query ($query){
    global $database;
  $tampilkan = mysqli_query($database, $query);
  $wadahkosong = [];
  while( $data =mysqli_fetch_assoc($tampilkan)){
    $wadahkosong [] =$data;
  }
  return $wadahkosong;
}
function tambah ($data){
    global $database;
    $nama=$_POST["nama"];
    $hobi=$_POST["hobi"];
    $alamat=$_POST["alamat"];
    $telepon=$_POST["telepon"];
    $jenis_kelamin=$_POST["jenis_kelamin"];
    $skil=$_POST["skil"];
    $pendidikan=$_POST["pendidikan"];
    $pekerjaan=$_POST["pekerjaan"];
    $kepribadian=$_POST["kepribadian"];


    $tambah="insert into isi values
    ('','$nama','$hobi','$alamat','$telepon','$jenis_kelamin','$skil','$pendidikan','$pekerjaan','$kepribadian')";

    mysqli_query($database, $tambah);
    return mysqli_affected_rows($database);
}

function hapus ($hapus){
    global $database;
    mysqli_query($database,"delete from isi where no=$hapus");
    return mysqli_affected_rows($database);
}

function edit ($edit){
    global $database;
    $hapus=$_GET["no"];
    $no=$_POST["no"];
    $nama=$_POST["nama"];
    $hobi=$_POST["hobi"];
    $alamat=$_POST["alamat"];
    $telepon=$_POST["telepon"];
    $jenis_kelamin=$_POST["jenis_kelamin"];
    $skil=$_POST["skil"];
    $pendidikan=$_POST["pendidikan"];
    $pekerjaan=$_POST["pekerjaan"];
    $kepribadian=$_POST["kepribadian"];
    $edit="update isi set

   nama ='$nama',
    hobi ='$hobi',
   alamat ='$alamat',
   telepon ='$telepon',
   jenis_kelamin ='$jenis_kelamin',
   skil ='$skil',
   pendidikan ='$pendidikan',
   pekerjaan ='$pekerjaan',
   kepribadian ='$kepribadian'
   
   where no=$hapus";
    mysqli_query($database, $edit);
    return mysqli_affected_rows($database);
}

function queryAdmin ($queryAdmin){
  global $database;
$tampilkan = mysqli_query($database, $query);
$wadahkosong = [];
while( $data =mysqli_fetch_assoc($tampilkan)){
  $wadahkosong [] =$data;
}
return $wadahkosong;
}
function tambahAdmin ($tambahAdmin){
  global $database;
  $no=$_POST["no"];
  $username=$_POST["username"];
  $password=$_POST["password"];
  $tambah_admin="insert into user values
  ('','$username','$password')"; 
 
  mysqli_query($database,$tambah_admin);
  return mysqli_affected_rows($database);
}

function hapusAdmin ($hapusAdmin){
  global $database;
  mysqli_query($database,"delete from user where no=$hapusAdmin");
  return mysqli_affected_rows($database);
}

function editAdmin($editAdmin){
  global $database;
  $hapus=$_GET["no"];

  
  $username=$_POST["username"];
  $password=$_POST["password"];
  $edit = "update user set  

  username = '$username',
  password ='$password'
  where no =$hapus"; 
  mysqli_query($database,$edit);
  return mysqli_affected_rows($database);
}
?>