<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';

if(isset($_POST["tombol"])){
    
     
   

    if(tambah($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Ditambahkan');
        document.location.href='data-cv.php';
        </script>
        ";
        }
        else{echo"Gagal";}

}

?>
<!doctype html>
<html>
<head>
<title>Tambah data</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">data cv</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a></li>
          <li class="menu-item"><a href="data-cv.php">Data CV</a></li>
          <li class="menu-item"><a href="data-admin.php">Data Admin</a></li>
          <li class="menu-item"><a href="keluar.php">Keluar</a></li>
         </ul>
    </div>
    <div class="konten">

<h1> Tambah data </h1>
<br>
<form method="POST">

<ul>

<li><label> NAMA </label></li>
<li><input type="text" name="nama"></li>
<li><label> HOBI </label></li>
<li><input type="text" name="hobi"></li>
<li><label> ALAMAT </label></li>
<li><input type="text" name="alamat"></li>
<li><label> TELEPON </label></li>
<li><input type="text" name="telepon"></li>
<li><label> JENIS KELAMIN</label></li>
<li>
    <select name="jenis_kelamin" required>
    <option>Laki-laki</option>
    <option>Perempuan</option>
    </select>
    </li>
<li><label> SKIL </label></li>
<li><input type="text" name="skil"></li>
<li><label> PENDIDIKAN </label></li>
<li><textarea  name="pendidikan"></textarea></li>
<li><label> PEKERJAAN </label></li>
<li><textarea name="pekerjaan" id=""></textarea></li>
<li><label> KEPRIBADIAN </label></li>
<li><textarea name="kepribadian" id=""></textarea></li>
<li><button type="submit" name="tombol"> Simpan </button> </li>
</ul>

</form>
</div>
</body>
</html> 