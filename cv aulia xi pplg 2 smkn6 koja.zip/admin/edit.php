<?php
session_start();
if (!isset($_SESSION["login"])){
    header ("Location: login.php");
    exit;
}
require 'function.php';

$hapus=$_GET["no"];
$data=mysqli_query($database,"select*from isi where no=$hapus");

if(isset($_POST["tombol"])){
    
     
   

    if(edit($_POST)>0){
        echo "
        <script>
        alert('Data Berhasil Diperbarui');
        document.location.href='data-cv.php';
        </script>
        ";
        }
        else{echo"Gagal";}

}

?>


<!doctype html>
<html>
<head>
<title>Edit data</title>
<link rel="stylesheet" type="text/css" href="style.css">

</head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logo.png" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">data cv</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a></li>
        <li class="menu-item"><a href="data-cv.php">Data CV</a></li>
          <li class="menu-item"><a href="data-admin.php">Data Admin</a></li>
        <li class="menu-item"><a href="keluar.php">Keluar</a></li>
         </ul>
    </div>
    <div class="konten">

<?php
while( $cari=mysqli_fetch_assoc($data)):


?>

<h1> Edit data </h1>
<br>
<form method="POST">
<input type="hidden" name="no" value="<?php echo $cari["no"]  ?>">


<ul>
<li><label> NAMA </label></li>
<li><input type="text" name="nama" value="<?php echo $cari["nama"];  ?>"></li>
<li><label> HOBI </label></li>
<li><input type="text" name="hobi" value="<?php echo $cari["hobi"];  ?>"></li>
<li><label> ALAMAT  </label></li>
<li><input type="text" name="alamat" value="<?php echo $cari["alamat"];   ?>"></li>
<li><label> NO.TELEPON </label></li>
<li><input type="text" name="telepon" value="<?php echo $cari["telepon"];   ?>"></li>
<li><label> JENIS KELAMIN </label></li>
<li>
    <select name="jenis_kelamin" required>
        <option value="">Pilih</option>
        <?php
        if ($cari["jenis_kelamin"]=="Laki-laki") echo "<option value='Laki-laki' selected>Laki-laki </option>";
        else echo "<option value='Laki-laki' selected>Laki-laki </option>";

        if ($cari["jenis_kelamin"]=="Perempuan") echo "<option value='Perempuan' selected>Perempuan </option>";
        else echo "<option value='Perempuan' selected>Perempuan </option>";

       
        ?>
    </select>
    </li>
<li><label> SKIL </label></li>
<li><input type="text" name="skil" value="<?php echo $cari["skil"];  ?>"></li>
<li><label> PENDIDIKAN </label></li>
<li><textarea  name="pendidikan"><?php echo $cari["pendidikan"]  ?></textarea></li>
<li><label> PEKERJAAN </label></li>
<li><textarea  name="pekerjaan"><?php echo $cari["pekerjaan"]  ?></textarea></li>
<li><label> KEPRIBADIAN </label></li>
<li><textarea  name="kepribadian"><?php echo $cari["kepribadian"]  ?></textarea></li>

<li><button type="submit" name="tombol"> Diperbarui </button> </li>
</ul>

<?php
endwhile;
?>

</form>
</div>
</body>
</html> 